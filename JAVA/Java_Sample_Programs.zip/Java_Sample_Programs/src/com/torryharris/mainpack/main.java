package com.torryharris.mainpack;

import com.torryharris.mainpack.products.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class main {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        List<Item> itemList=new ArrayList<>();

        for(int i=1;i>0;i++){
            Item item=new Item();
            System.out.println("enter product "+i+" details");
            System.out.println("Enter item code");
            item.setItemCode(sc.nextInt());
            System.out.println("Enter item description");
            item.setDescription(sc.next());
            System.out.println("Enter item quantity");
            item.setQuantity(sc.nextInt());
            System.out.println("Enter item price");
            item.setPrice(sc.nextDouble()*item.getQuantity());
            itemList.add(item);
            System.out.println("Do you want to continue? (y/n)");
            if(sc.next().equalsIgnoreCase("N")){
                break;
            }
        }

        //display all products
        System.out.println("Your purchases are:");
        double total=0.0;
        for (Item i :itemList) {
            System.out.println(i);
            total+=i.getPrice();

        }

        if(total>1000){
            System.out.println("The grand total is: "+total);
            System.out.println("The discounted total is: "+(total-((0.10)*total)));
           // System.out.println(numberToWord((int)(total-((0.10)*total)))+"rupees only");
        }
        else if(total<1000){
            System.out.println("Are you paying by cash or card?");
            if (sc.next().equalsIgnoreCase("card")){
                double surcharge =(0.0025*total);
                System.out.println("surcharge: "+surcharge);
                System.out.println("The total is: "+total);
                System.out.println("The grand total is: "+(total+surcharge));
             //   System.out.println(numberToWord((int)(total+surcharge))+"rupees only");

            }

        }else{
          //  System.out.println(numberToWord((int)(total))+"rupees only");

        }
    }
}
