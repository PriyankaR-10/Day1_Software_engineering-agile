package com.torryharris.mainpack;

import java.util.Scanner;

public class Exponent {
    public static void main(String[] args) {

        int base, exponent;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the base and exponent value");
        base= sc.nextInt();
        exponent= sc.nextInt();
        int pow = exponent;

        long result = 1;
        for(int i=1;i<=exponent;i++)
        {
            result*=base;
        }

        System.out.println(base+" to the power of "+pow+" is " +result);
    }
}