package com.torryharris.mainpack;

import java.util.Scanner;

public class DecimalToBinary
{
    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Decimal number : ");
        n = sc.nextInt();
        System.out.println(Integer.toBinaryString(n));
    }
}
