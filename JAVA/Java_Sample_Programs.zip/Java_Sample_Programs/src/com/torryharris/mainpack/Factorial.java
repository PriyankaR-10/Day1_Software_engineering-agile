package com.torryharris.mainpack;

import java.util.Scanner;

public class Factorial
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n, i=1, fact=1;
        System.out.println("Enter a number : ");
        n = sc.nextInt();
        if(n==0)
        {
            System.out.println("Factorial of 0 is : 1.");
        }
        else if(n<0)
        {
            System.out.println("Factorial of negative number is not possible.");
        }
        else
        {
            for(i=1;i<=n;i++)
            {
                fact = fact * i;
            }
            System.out.println("Factorial of "+n+" is : "+fact);
        }
    }
}
