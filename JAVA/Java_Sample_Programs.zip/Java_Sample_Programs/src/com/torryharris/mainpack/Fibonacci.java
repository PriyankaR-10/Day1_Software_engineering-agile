package com.torryharris.mainpack;

import java.util.Scanner;

public class Fibonacci
{
    static boolean isPerfectSquare(int x)
    {
        int s = (int)Math.sqrt(x);
        return (s*s == x);
    }
    static boolean isFibonacci(int n)
    {
        return(isPerfectSquare(5*n*n + 4) || isPerfectSquare(5*n*n - 4));
    }
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number : ");
        int n = sc.nextInt();
        for(int i=1;i<=n;i++)
        {
            if(isFibonacci(i))
            {
                System.out.println(i+" is a Fibonacci number.");
            }
            else
            {
                System.out.println(i+" is not a Fibonacci number.");
            }
        }
    }
}
