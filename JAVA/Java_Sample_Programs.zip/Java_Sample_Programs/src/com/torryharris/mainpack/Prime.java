package com.torryharris.mainpack;
import java.util.Scanner;
public class Prime {
    public static void main(String args[])
    {
        int n,m,flag,count=0,sum=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the range : ");
        m = sc.nextInt();
        n = sc.nextInt();
        for(int i=m;i<=n;i++)
        {
            if(i==1 || i==0)
            {
                continue;
            }
            flag = 1;
            for(int j=2;j<=i/2;j++)
            {
                if(i % j == 0)
                {
                    flag = 0;
                    count++;
                    break;
                }
            }
            if(flag == 1)
            {
                System.out.println(i);
            }
//            if(count == 0 && i != 1)
//            {
//                sum=sum+i;
//                System.out.println(sum);
//            }
        }
        //System.out.print("The sum of prime numbers are : "+sum);
    }
}