package com.thbs.b84.repository;
import com.thbs.b84.model.*;
import java.util.*;

public class PersonRepository 
{
	List<Person> blist;
	
	public PersonRepository()
	{
		blist = new ArrayList<Person>();
		
		Person p1 = new Person();
		p1.setPersonId(10);
		p1.setPersonName("ASHWIN");
		p1.setPersonAge(21);
		
		Person p2 = new Person();
		p2.setPersonId(20);
		p2.setPersonName("PRIYANKA");
		p2.setPersonAge(22);
		
		Person p3 = new Person();
		p3.setPersonId(30);
		p3.setPersonName("ANJANA");
		p3.setPersonAge(22);
		
		blist.add(p1);
		blist.add(p2);
		blist.add(p3);
	}
	public List<Person> getAllPerson()
	{
		return blist;
	}
}
