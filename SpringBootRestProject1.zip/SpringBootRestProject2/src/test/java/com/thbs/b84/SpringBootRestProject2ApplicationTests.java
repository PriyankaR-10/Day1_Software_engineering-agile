package com.thbs.b84;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
