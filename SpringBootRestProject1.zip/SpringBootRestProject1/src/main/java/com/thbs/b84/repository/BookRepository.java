package com.thbs.b84.repository;
import com.thbs.b84.model.*;
import java.util.*;

public class BookRepository 
{
	List<Book> blist;
	
	public BookRepository()
	{
		blist = new ArrayList<Book>();
		
		Book b1 = new Book();
		b1.setBookId(100);
		b1.setBookName("JAVA");
		b1.setBookPrice(300);
		
		Book b2 = new Book();
		b2.setBookId(200);
		b2.setBookName("Hibernate");
		b2.setBookPrice(700);
		
		Book b3 = new Book();
		b3.setBookId(300);
		b3.setBookName("Python");
		b3.setBookPrice(900);
		
		blist.add(b1);
		blist.add(b2);
		blist.add(b3);
	}
	public List<Book> getAllBooks()
	{
		return blist;
	}
	
	public Book getABook(int bookId)
	{
		for(Book b:blist)
		{
			if(b.getBookId()==bookId)
				return b;
		}
		return null;
	}
}
