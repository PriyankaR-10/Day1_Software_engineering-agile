package torryharris.b84.SpringJdbcdemo1;

public class Book {
	private int TrainId;
	private String TrainName;
	
	private String Source;
	private String Destination;
	private int TicketPrice;
	public int getTrainId() {
		return TrainId;
	}
	public void setTrainId(int trainId) {
		TrainId = trainId;
	}
	public String getTrainName() {
		return TrainName;
	}
	public void setTrainName(String trainName) {
		TrainName = trainName;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public int getTicketPrice() {
		return TicketPrice;
	}
	public void setTicketPrice(int ticketPrice) {
		TicketPrice = ticketPrice;
	}
	@Override
	public String toString() {
		return "Book [TrainId=" + TrainId + ", TrainName=" + TrainName + ", Source=" + Source + ", Destination="
				+ Destination + ", TicketPrice=" + TicketPrice + "]";
	}
	
	
	
	

}
