package torryharris.b84.SpringJdbcdemo1;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class BookDAO1  implements CRUDOperations{
       private JdbcTemplate jdbcTemplate;
	
	public BookDAO1(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	
	@Override
	public void insert(Book book) {
		
		if (null != book) {

         // Prepared statement in JDBC : insert statement below 			
			jdbcTemplate.update(
					"insert into TRAINS values(?,?,?,?,?)",
					new Object[] { book.getTrainId(),
							book.getTrainName(),book.getSource(),book.getDestination(),book.getTicketPrice() });
		
	}
		
	}
	
	
public List<Book> selectAll(){
		
		return	jdbcTemplate.query("select * from TRAINS", new RowMapper<Book>() {
           // ResultSet rs = st.executeQuery("Select * from employee");
			
			
			@Override
			public Book mapRow(ResultSet resultSet, int arg1) throws SQLException {
				Book book = new Book();
				book.setTrainId(resultSet.getInt(1));
				book.setTrainName(resultSet.getString(2));
				
				book.setSource(resultSet.getString(3));
				book.setDestination(resultSet.getString(4));
				book.setTicketPrice(resultSet.getInt(5));
				return book;

			}
		});
		}

//
//public List<Book> select(Book book,int Id){
//	
//	return	jdbcTemplate.query("select * from TRAINS where TRAIN_NO=?",new Object[] { book.getTrainId() }); new RowMapper<Book>() {
//       // ResultSet rs = st.executeQuery("Select * from employee");
//		
//		
//		@Override
//		public Book mapRow(ResultSet resultSet, int arg1) throws SQLException {
//			Book book = new Book();
//			book.setTrainId(resultSet.getInt(1));
//			book.setTrainName(resultSet.getString(2));
//			
//			book.setSource(resultSet.getString(3));
//			book.setDestination(resultSet.getString(4));
//			book.setTicketPrice(resultSet.getInt(5));
//			return book;
//
//		}
//	});
//	}




public Book select(int TrainId) {
	return (Book) jdbcTemplate.queryForObject(
			"SELECT * FROM TRAINS WHERE TRAIN_NO=?",
			new Object[] { Integer.valueOf(TrainId) },
			new RowMapper<Book>() {

				@Override
				public Book mapRow(ResultSet resultSet, int arg1)
						throws SQLException {
					Book book = new Book();
					book.setTrainId(resultSet.getInt(1));
					book.setTrainName(resultSet.getString(2));
				
					book.setSource(resultSet.getString(3));
					book.setDestination(resultSet.getString(4));
					book.setTicketPrice(resultSet.getInt(5));
					return book;
				}
			});
}

}
