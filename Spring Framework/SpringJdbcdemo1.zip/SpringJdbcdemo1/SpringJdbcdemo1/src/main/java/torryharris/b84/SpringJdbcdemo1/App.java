package torryharris.b84.SpringJdbcdemo1;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("file:src/main/java/beans.xml");
        
        BookDAO1 dao=(BookDAO1)ctx.getBean("bookDAO");
        Book book=new Book();
        book.setTrainId(1012);
        book.setTrainName("Andhra");
        book.setTicketPrice(125);
        book.setSource("pavn");
        book.setDestination("iyurte");
        
        dao.insert(book);
        System.out.println("The train table records are as follows");
        for(Book b:dao.selectAll()) {
        	System.out.println(b.getTrainId()+" "+b.getTrainName()+" "+b.getSource()+" "+b.getDestination()+" "+b.getTicketPrice());  
        	 } 

        	Book b = dao.select(1002);
        	System.out.println("*********");
        	System.out.println(b.getTrainId()+" "+b.getTrainName()+" "+b.getSource()+" "+b.getDestination()+" "+b.getTicketPrice());
         
         	 } 
;
       
    }
    

